### Homework 3, Q1.1

library(shiny)
library(ggplot2)
library(dplyr)

# Define UI for application that draws a histogram
ui <- fluidPage(

    fluidRow(column(4,
        
            numericInput(inputId = "n_obs", 
                        "Number of Observations",
                        6,
                        min = 1,
                        max = 20,
                        step = 1),
            tableOutput("table")
        ))
    )

server <- function(input, output) {

    output$table <- renderTable({
        head(mpg, n = (input$n_obs))
         
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
