### Homework 3, Q1.2

library(shiny)


ui <- fluidPage(
    fluidRow(column(4,
            radioButtons(inputId = "city", 
                        label = "Choose a City",
                        choices = list("Austin","Dallas","El Paso","Houston","San Antonio"),
                        selected = "San Antonio"),
            textOutput("feedback"))
    )
    )

server <- function(input, output){
    output$feedback <- renderText(paste("You selected",
                                        input$city))
}

shinyApp(ui = ui, server = server)
