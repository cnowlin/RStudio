### Homework 3, Q2

library(shiny)
library(ggplot2)


ui <- fluidPage(
    fluidRow(column(4,
            sliderInput("n_obs",
                        "Number of Observations",
                        min = 50,
                        max = 200,
                        step = 5,
                        value = 100),
            
            sliderInput("n_bins",
                         "Number of Bins",
                         min = 10,
                         max = 50,
                         step = 1, 
                         value = 20),
            
            selectInput("color",
                         "Color Fill",
                         choices = list("blue", "red", "green", "yellow", "black")),
            
            selectInput("border",
                        "Border Color",
                        choices = list("red", "white", "black")
            )),
            column(8,
                   plotOutput("histPlot"))
        )
)
server <- function(input, output) {

    output$histPlot <- renderPlot({
        plot1 <- data.frame(randvec = rnorm(input$n_obs), x = (randvec = rnorm(input$n_obs))) 
        ggplot(plot1, aes(x)) + 
            geom_histogram(bins = input$n_bins, fill = input$color, col = input$border, show.legend = FALSE) +
            labs(x = "Random Numbers",
                 y = "Count") + 
            theme_bw()
        
    })
}

shinyApp(ui = ui, server = server)
