# Homework 3, Q1.3

library(shiny)
library(lubridate)

ui <- fluidPage(
    fluidRow(column(4,
            dateInput("date","Date", value = "2018-09-18",min = NULL, max = NULL,
                      format = "yyyy-mm-dd", startview = "month", weekstart = 0,
                      language = "en", width = NULL, autoclose = FALSE,
                      datesdisabled = NULL, daysofweekdisabled = NULL),
            textOutput("day"))
        
    )
)

server <- function(input, output) {
    output$day <- renderText(day(input$date))
}

shinyApp(ui = ui, server = server)
